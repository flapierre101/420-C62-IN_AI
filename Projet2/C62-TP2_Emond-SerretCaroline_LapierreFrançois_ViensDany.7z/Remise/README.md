# 420-C62-IN_AI
420-C62-IN - Données, mégadonnées et intelligence artificielle II

### Voir le dossier Projet2

## Équipe : 
- Emond-Serret, Caroline_
- Lapierre, François_
- Viens, Dany

## Bonus
### Gestion d'erreurs
* Table séparée contenant les textes déjà entraînés
* Vérification si un texte a déjà été entraîné avec taille de fenêtre x
    * Si oui, message de choisir nouveau texte ou nouvelle taille de fenêtre
* Vérification si type encodage et chemin texte valide
* Vérification si script appellé sans aucun argument





