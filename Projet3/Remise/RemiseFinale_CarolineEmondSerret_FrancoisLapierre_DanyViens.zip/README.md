# 420-C62-IN_AI
420-C62-IN - Données, mégadonnées et intelligence artificielle II

## Projet 3

## Équipe : 
- Emond-Serret, Caroline
- Lapierre, François
- Viens, Dany

## Configuration

Pour lancer l'algorithme à partir d'une fenêtre de commande :

    py main.py -c -t 5 -k 1 -n 10 

Il est possible d'utiliser 6 valeurs pour le nombre de clusters (K)

    10, 20 ,50, 100, 250, 500

Il est possible d'utiliser 3 valeurs pour la taille de fenêtre (T)

    5, 7, 9

Pour l'affichage du nombre de mots, nous avons testez avec 5 et 10 (n)
