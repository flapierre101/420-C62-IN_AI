
from options import Options


def main():
    options = Options()
    options.start()

if __name__ == '__main__':
    quit(main())
